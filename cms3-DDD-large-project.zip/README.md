# CMS3‑FAST VR Demo

Static A‑Frame scene visualizing large_DDD_model GLB model.

📦 **Live Demo**: https://aitorrc.github.io/cms3-DDD-large-project/

---

## How to use

1. Clone or fork this repository.
2. Ensure `index.html` is at the root.
3. Visit the live link via GitHub Pages.
